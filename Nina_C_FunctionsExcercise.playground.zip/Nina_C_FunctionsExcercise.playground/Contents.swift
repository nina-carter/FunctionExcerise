import UIKit

var a = 69
var b = 420

func plus(min: Int, max: Int) -> Int {
    let a = 69
    let b = 420
    return a + b
}
print(plus(min: a, max: b))
